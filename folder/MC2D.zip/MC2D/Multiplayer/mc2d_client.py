# mc2d_client.py
# Multiplayer client for the 2D Minecraft-like game.
# Run: python mc2d_client.py [host] [port]
import pygame, sys, math, json, socket, threading, time

HOST = input("enter server ip: ")
PORT = int(input("enter server port: "))

# ---- Config (match server) ----
SCREEN_W, SCREEN_H = 1920, 1020
TILE = 24
REACH = 5

AIR, GRASS, DIRT, LOG, LEAF = 0,1,2,3,4

COL = {
    "sky_top": (124,198,255),
    "sky_bot": (205,238,255),
    "grass_top": (76,175,80),
    "grass_mid": (62,142,65),
    "dirt_top": (141,110,99),
    "dirt_bot": (109,76,65),
    "log_light": (122,79,46),
    "log_dark": (93,59,34),
    "leaf_light": (96,179,90),
    "leaf_dark": (62,143,67),
}

pygame.init()
screen = pygame.display.set_mode((SCREEN_W, SCREEN_H))
pygame.display.set_caption("mc2d - online (demo)")
clock = pygame.time.Clock()
FONT = pygame.font.SysFont("arial", 16)

def draw_sky():
    top = COL["sky_top"]; bot = COL["sky_bot"]
    for i in range(SCREEN_H):
        t = i / SCREEN_H
        r = int(top[0]*(1-t) + bot[0]*t)
        g = int(top[1]*(1-t) + bot[1]*t)
        b = int(top[2]*(1-t) + bot[2]*t)
        pygame.draw.line(screen, (r,g,b), (0,i), (SCREEN_W,i))

def draw_block(b, sx, sy):
    if b == GRASS:
        pygame.draw.rect(screen, COL["grass_mid"], (sx, sy, TILE, TILE))
        pygame.draw.rect(screen, COL["grass_top"], (sx, sy, TILE, TILE//2))
    elif b == DIRT:
        pygame.draw.rect(screen, COL["dirt_bot"], (sx, sy, TILE, TILE))
    elif b == LOG:
        pygame.draw.rect(screen, COL["log_light"], (sx, sy, TILE, TILE))
        for i in range(2, TILE, 5):
            pygame.draw.rect(screen, COL["log_dark"], (sx+i, sy, 2, TILE))
    elif b == LEAF:
        pygame.draw.rect(screen, COL["leaf_dark"], (sx, sy, TILE, TILE))
        pygame.draw.rect(screen, COL["leaf_light"], (sx+4, sy+4, TILE-8, TILE-8))

# --- Networking ---
class NetClient:
    def __init__(self, host, port):
        self.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.s.connect((host, port))
        self.f = self.s.makefile("r")
        self.lock = threading.Lock()
        self.inbox = []
        self.running = True
        # send join
        self.send({"t":"join","name":"Player","version":1})
        threading.Thread(target=self.reader, daemon=True).start()

    def send(self, obj):
        try:
            data = (json.dumps(obj) + "\n").encode("utf-8")
            self.s.sendall(data)
        except Exception:
            pass

    def reader(self):
        try:
            for line in self.f:
                try:
                    msg = json.loads(line)
                except:
                    continue
                with self.lock:
                    self.inbox.append(msg)
        except Exception:
            pass
        finally:
            self.running = False

    def poll(self):
        with self.lock:
            out = self.inbox[:]
            self.inbox.clear()
        return out

# --- Client game state ---
class ClientGame:
    def __init__(self):
        self.world = None
        self.seed = None
        self.pid = None
        self.players = {}  # pid -> {x,y,vx,vy,sel,inv}
        self.me = {"x": 0, "y": 0, "sel": 1, "inv":{"grass":0,"log":0}}
        self.camera_x = 0.0
        self.camera_y = 0.0
        self.mouse = {"down": False, "button": 0, "x":0, "y":0}
        self.last_input_send = 0

    def apply_msg(self, msg):
        t = msg.get("t")
        if t == "welcome":
            self.pid = msg["pid"]
            self.seed = msg.get("seed")
            self.world = msg["world"]
        elif t == "state":
            for p in msg.get("players",[]):
                self.players[p["pid"]] = p
                if p["pid"] == self.pid:
                    self.me["x"] = p["x"]; self.me["y"] = p["y"]
                    self.me["sel"] = p["sel"]; self.me["inv"] = p["inv"]
        elif t == "set":
            x,y,b = msg["x"], msg["y"], msg["b"]
            if 0 <= y < len(self.world) and 0 <= x < len(self.world[0]):
                self.world[y][x] = b
        elif t == "leave":
            self.players.pop(msg["pid"], None)

    def send_input(self, net):
        now = time.time()
        if now - self.last_input_send < 1/30:  # throttle a little
            return
        self.last_input_send = now
        keys = pygame.key.get_pressed()
        left = keys[pygame.K_a] or keys[pygame.K_LEFT]
        right = keys[pygame.K_d] or keys[pygame.K_RIGHT]
        jump = keys[pygame.K_w] or keys[pygame.K_SPACE] or keys[pygame.K_UP]

        mx_world = self.camera_x + self.mouse["x"] / TILE
        my_world = self.camera_y + self.mouse["y"] / TILE
        mtx, mty = int(mx_world), int(my_world)

        net.send({
            "t":"input",
            "keys":{"left":bool(left),"right":bool(right),"jump":bool(jump)},
            "mouse":{"tx":mtx,"ty":mty,"l": self.mouse["down"] and self.mouse["button"]==1,
                     "r": self.mouse["down"] and self.mouse["button"]==3},
            "selected": self.me["sel"]
        })

def main():
    net = NetClient(HOST, PORT)
    game = ClientGame()

    # Simple wait for welcome
    print("[CLIENT] Connecting to", HOST, PORT)
    while game.world is None and net.running:
        for msg in net.poll():
            game.apply_msg(msg)
        time.sleep(0.01)
    if game.world is None:
        print("[CLIENT] Failed to receive world. Exiting.")
        return

    WORLD_H = len(game.world); WORLD_W = len(game.world[0])

    running = True
    while running and net.running:
        dt = clock.tick(60) / 1000.0
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                running = False
            elif e.type == pygame.KEYDOWN:
                if e.key == pygame.K_ESCAPE:
                    running = False
                if e.key == pygame.K_1: game.me["sel"] = 0
                if e.key == pygame.K_2: game.me["sel"] = 1
                if e.key == pygame.K_3: game.me["sel"] = 2
            elif e.type == pygame.MOUSEMOTION:
                game.mouse["x"], game.mouse["y"] = e.pos
            elif e.type == pygame.MOUSEBUTTONDOWN:
                game.mouse["down"] = True; game.mouse["button"] = e.button
            elif e.type == pygame.MOUSEBUTTONUP:
                game.mouse["down"] = False

        # Apply incoming network messages
        for msg in net.poll():
            game.apply_msg(msg)

        # Camera follows me (server-authoritative positions)
        target_x = game.me["x"] - (SCREEN_W / TILE) / 2
        target_y = game.me["y"] - (SCREEN_H / TILE) / 2
        game.camera_x = game.camera_x + (target_x - game.camera_x) * 0.12
        game.camera_y = game.camera_y + (target_y - game.camera_y) * 0.12

        # Send inputs
        game.send_input(net)

        # --- Draw ---
        draw_sky()

        # Visible range
        min_tx = max(0, int(math.floor(game.camera_x)) - 2)
        max_tx = min(WORLD_W - 1, int(math.floor(game.camera_x + SCREEN_W / TILE)) + 2)
        min_ty = max(0, int(math.floor(game.camera_y)) - 2)
        max_ty = min(WORLD_H - 1, int(math.floor(game.camera_y + SCREEN_H / TILE)) + 2)

        # Tiles
        for ty in range(min_ty, max_ty + 1):
            row = game.world[ty]
            for tx in range(min_tx, max_tx + 1):
                b = row[tx]
                if b == AIR: continue
                sx = (tx - game.camera_x) * TILE
                sy = (ty - game.camera_y) * TILE
                draw_block(b, sx, sy)

        # Target highlight
        mx_world = game.camera_x + game.mouse["x"] / TILE
        my_world = game.camera_y + game.mouse["y"] / TILE
        mtx, mty = int(mx_world), int(my_world)
        hx = (mtx - game.camera_x) * TILE
        hy = (mty - game.camera_y) * TILE
        pygame.draw.rect(screen, (255,255,255), (hx+1, hy+1, TILE-2, TILE-2), 2)

        # Players
        for pid, p in game.players.items():
            px = (p["x"] - game.camera_x) * TILE
            py = (p["y"] - game.camera_y) * TILE
            pw = 0.8 * TILE; ph = 1.8 * TILE
            color = (194,209,255) if pid == game.pid else (230,180,120)
            pygame.draw.rect(screen, color, (px, py, pw, ph))
            pygame.draw.rect(screen, (0,0,0), (px + pw*0.2, py + ph*0.3, 4, 4))
            pygame.draw.rect(screen, (0,0,0), (px + pw*0.6, py + ph*0.3, 4, 4))
            pygame.draw.rect(screen, (0,0,0), (px + pw*0.4, py + ph*0.6, pw*0.2, 3))
            name = FONT.render(f"P{pid}", True, (20,20,20))
            screen.blit(name, (px, py-16))

        # HUD
        inv = game.me["inv"]
        hud = FONT.render(f"PID {game.pid}  Inv: Grass {inv.get('grass',0)}  Log {inv.get('log',0)}", True, (255,255,255))
        screen.blit(hud, (8, SCREEN_H - 28))

        # Hotbar
        labels = ["Air", "Grass", "Log"]
        for i in range(3):
            rx = SCREEN_W//2 - 200 + i*140
            ry = 8
            rect = pygame.Rect(rx, ry, 120, 44)
            pygame.draw.rect(screen, (60,60,60), rect, border_radius=8)
            if game.me["sel"] == i:
                pygame.draw.rect(screen, (255,255,255), rect, 3, border_radius=8)
            txt = FONT.render(f"{i+1} {labels[i]}", True, (240,240,240))
            screen.blit(txt, (rx+8, ry+12))

        pygame.display.flip()

    try: net.s.close()
    except: pass
    pygame.quit()

if __name__ == "__main__":
    main()
