# mc2d_server.py
# Simple server-authoritative multiplayer for the 2D Minecraft-like game.
# Run: python mc2d_server.py [port]
import socket, threading, json, time, math, random, sys

HOST = "127.0.0.1"
PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 5055

# ---- Shared Config (mirror client) ----
TILE = 24
WORLD_W = 300
WORLD_H = 120
GRAVITY = 40.0
JUMP_V = 14.0
WALK_ACC = 80.0
FRICTION = 22.0
MAX_VX = 10.0
MAX_VY = 60.0
REACH = 5
TICK_RATE = 20  # server ticks per second

AIR, GRASS, DIRT, LOG, LEAF = 0,1,2,3,4
SOLID = {GRASS, DIRT, LOG}
BREAKABLE = {GRASS, DIRT, LOG, LEAF}

SEED = random.randint(1,10**9)

def pseudo_noise1d(x):
    n = int(x * 1000) ^ SEED
    n = (n << 13) ^ n
    nn = (n * (n * n * 15731 + 789221) + 1376312589) & 0x7fffffff
    return 1.0 - nn / 1073741824.0

def smooth_noise(x):
    xi = math.floor(x)
    t = x - xi
    a = pseudo_noise1d(xi)
    b = pseudo_noise1d(xi+1)
    return a*(1-t) + b*t

def height_at(x):
    n1 = smooth_noise(x * 0.013) * 18
    n2 = smooth_noise(x * 0.05) * 7
    return int(50 + n1 + n2)

def tree_chance(x):
    return (pseudo_noise1d(x * 0.07) + 1) * 0.5

def generate_world(width=WORLD_W, height=WORLD_H):
    world = [[AIR for _ in range(width)] for _ in range(height)]
    for tx in range(width):
        ground = max(3, min(height-3, height_at(tx)))
        for ty in range(height):
            if ty > ground:
                world[ty][tx] = DIRT
            elif ty == ground:
                world[ty][tx] = GRASS
            else:
                world[ty][tx] = AIR
        if tree_chance(tx) > 0.74 and world[ground][tx] == GRASS:
            place_tree(world, tx, ground)
    return world

def place_tree(world, tx, ground):
    h = random.randint(4,7)
    H = len(world); W = len(world[0])
    for i in range(h):
        gy = ground - i
        if 0 <= gy < H: world[gy][tx] = LOG
    top = ground - h
    radius = random.randint(2,3)
    for dy in range(-radius, radius+1):
        for dx in range(-radius, radius+1):
            if abs(dx)+abs(dy) <= radius + (random.random() < 0.25):
                x = tx + dx; y = top + dy
                if 0 <= x < W and 0 <= y < H and world[y][x] == AIR:
                    world[y][x] = LEAF

def in_bounds(tx, ty, world):
    return 0 <= tx < len(world[0]) and 0 <= ty < len(world)

def get_block(world, tx, ty):
    if not in_bounds(tx,ty,world): return DIRT
    return world[ty][tx]

def set_block(world, tx, ty, val):
    if in_bounds(tx,ty,world):
        world[ty][tx] = val
        return True
    return False

def hits_solid(world, px, py, w, h):
    minx = math.floor(px); miny = math.floor(py)
    maxx = math.floor(px + w); maxy = math.floor(py + h)
    for ty in range(miny, maxy+1):
        for tx in range(minx, maxx+1):
            if get_block(world, tx, ty) in SOLID: return True
    return False

def aabb_tile_collision(world, px, py, w, h, vx, vy):
    nx, ny = px + vx, py + vy
    dx, dy = vx, vy
    if vx != 0:
        step = math.copysign(0.05, vx)
        cx = px
        while (step > 0 and cx < nx) or (step < 0 and cx > nx):
            cx += step
            if hits_solid(world, cx, py, w, h):
                nx = cx - step
                dx = nx - px
                break
    if vy != 0:
        step = math.copysign(0.05, vy)
        cy = py
        while (step > 0 and cy < ny) or (step < 0 and cy > ny):
            cy += step
            if hits_solid(world, nx, cy, w, h):
                ny = cy - step
                dy = ny - py
                break
    collidedY = abs(vy - dy) > 1e-6
    return {"x": nx, "y": ny, "dx": dx, "dy": dy, "collidedY": collidedY}

class Player:
    def __init__(self, pid):
        self.pid = pid
        self.w = 0.8
        self.h = 1.8
        self.x = WORLD_W // 2 + 0.5
        self.y = height_at(WORLD_W//2) - self.h - 0.1
        self.vx = 0.0
        self.vy = 0.0
        self.on_ground = False
        self.selected = 1
        self.inv = {"grass":0, "log":0}
        self.left = self.right = self.jump = False
        self.want_break = False
        self.want_place = False
        self.mx = self.my = 0  # world-space tile target

class Server:
    def __init__(self, host, port):
        self.world = generate_world()
        self.players = {}       # pid -> Player
        self.sock_map = {}      # pid -> socket
        self.lock = threading.Lock()
        self.next_pid = 1
        self.running = True

        self.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.s.bind((host, port))
        self.s.listen(16)
        print(f"[SERVER] Listening on {host}:{port}  SEED={SEED}")

    def start(self):
        threading.Thread(target=self.accept_loop, daemon=True).start()
        self.game_loop()

    def accept_loop(self):
        while self.running:
            conn, addr = self.s.accept()
            conn.settimeout(10)
            print("[SERVER] New connection from", addr)
            threading.Thread(target=self.client_thread, args=(conn,), daemon=True).start()

    def send_json(self, conn, obj):
        try:
            data = (json.dumps(obj) + "\n").encode("utf-8")
            conn.sendall(data)
        except Exception:
            pass

    def broadcast(self, obj):
        msg = (json.dumps(obj) + "\n").encode("utf-8")
        dead = []
        with self.lock:
            for pid, conn in self.sock_map.items():
                try:
                    conn.sendall(msg)
                except Exception:
                    dead.append(pid)
        for pid in dead:
            self.drop_player(pid)

    def drop_player(self, pid):
        with self.lock:
            if pid in self.sock_map:
                try: self.sock_map[pid].close()
                except: pass
                del self.sock_map[pid]
            if pid in self.players:
                print(f"[SERVER] Player {pid} disconnected")
                del self.players[pid]
        # notify others
        self.broadcast({"t":"leave","pid":pid})

    def client_thread(self, conn):
        f = conn.makefile("r")
        pid = None
        try:
            # Expect join
            line = f.readline()
            if not line: return
            msg = json.loads(line)
            if msg.get("t") != "join":
                return
            with self.lock:
                pid = self.next_pid; self.next_pid += 1
                p = Player(pid)
                self.players[pid] = p
                self.sock_map[pid] = conn
            # Send welcome with full world
            self.send_json(conn, {"t":"welcome","pid":pid,"seed":SEED,"world":self.world})
            # Tell others someone joined
            self.broadcast({"t":"join","pid":pid})

            # Read loop
            for line in f:
                try:
                    msg = json.loads(line)
                except:
                    continue
                if msg.get("t") == "input":
                    with self.lock:
                        pl = self.players.get(pid)
                        if not pl: break
                        keys = msg.get("keys",{})
                        pl.left = bool(keys.get("left"))
                        pl.right = bool(keys.get("right"))
                        pl.jump = bool(keys.get("jump"))
                        mouse = msg.get("mouse",{})
                        pl.mx = int(mouse.get("tx", pl.mx))
                        pl.my = int(mouse.get("ty", pl.my))
                        pl.want_break = bool(mouse.get("l", False))
                        pl.want_place = bool(mouse.get("r", False))
                        pl.selected = int(msg.get("selected", pl.selected))
                elif msg.get("t") == "chat":
                    # naive chat broadcast
                    self.broadcast({"t":"chat","pid":pid,"m":msg.get("m","")})
        except Exception as e:
            # print("client_thread err:", e)
            pass
        finally:
            if pid is not None:
                self.drop_player(pid)

    def do_block_action(self, p, world):
        # reach check
        mtx, mty = p.mx, p.my
        reach = math.hypot(p.x - (mtx + 0.5), p.y - (mty + 0.5))
        if reach > REACH: 
            p.want_break = p.want_place = False
            return
        if p.want_break:
            b = get_block(world, mtx, mty)
            if b in BREAKABLE:
                if b == GRASS: p.inv["grass"] += 1
                if b == LOG: p.inv["log"] += 1
                if set_block(world, mtx, mty, AIR):
                    self.broadcast({"t":"set","x":mtx,"y":mty,"b":AIR})
            p.want_break = False
        elif p.want_place:
            # only grass or log from hotbar (0=Air,1=Grass,2=Log)
            sel = [AIR, GRASS, LOG][max(0, min(2, p.selected))]
            if sel == GRASS and p.inv["grass"] <= 0: sel = AIR
            if sel == LOG and p.inv["log"] <= 0: sel = AIR
            if sel != AIR and get_block(world, mtx, mty) == AIR:
                if set_block(world, mtx, mty, sel):
                    if sel == GRASS: p.inv["grass"] -= 1
                    if sel == LOG: p.inv["log"] -= 1
                    self.broadcast({"t":"set","x":mtx,"y":mty,"b":sel})
            p.want_place = False

    def step_player(self, p, dt):
        # Horizontal
        if p.left and not p.right:
            p.vx -= WALK_ACC * dt
        elif p.right and not p.left:
            p.vx += WALK_ACC * dt
        else:
            if abs(p.vx) < 0.1: p.vx = 0
            else: p.vx -= math.copysign(FRICTION * dt, p.vx)
        p.vx = max(-MAX_VX, min(MAX_VX, p.vx))
        # Jump
        if p.jump and p.on_ground:
            p.vy = -JUMP_V
            p.on_ground = False
        # Gravity
        p.vy += GRAVITY * dt
        p.vy = max(-MAX_VY, min(MAX_VY, p.vy))
        # Collide & move
        res = aabb_tile_collision(self.world, p.x, p.y, p.w, p.h, p.vx * dt, p.vy * dt)
        p.x = res["x"]; p.y = res["y"]
        p.on_ground = res["collidedY"] and p.vy > 0
        if p.on_ground: p.vy = 0.0

    def game_loop(self):
        prev = time.time()
        accum = 0.0
        tick = 1.0 / TICK_RATE
        while self.running:
            now = time.time()
            dt = now - prev
            prev = now
            accum += dt
            # fixed time step
            while accum >= tick:
                with self.lock:
                    for pid, p in list(self.players.items()):
                        self.step_player(p, tick)
                        self.do_block_action(p, self.world)
                accum -= tick
            # broadcast compact state ~20/s
            with self.lock:
                players_state = [{
                    "pid": pid, "x": p.x, "y": p.y,
                    "vx": p.vx, "vy": p.vy,
                    "sel": p.selected,
                    "inv": p.inv
                } for pid,p in self.players.items()]
            self.broadcast({"t":"state","players":players_state})
            time.sleep(max(0, tick - (time.time()-now)))

if __name__ == "__main__":
    Server(HOST, PORT).start()
